import streamlit as st
import pandas as pd
import joblib
from huggingface_hub import hf_hub_download

# Load trained model from Hugging Face Model Hub
MODEL_REPO = "shivkumark0911gl/tourism-wellness-model"

model_path = hf_hub_download(
    repo_id=MODEL_REPO,
    filename="best_rf_model.pkl",
    repo_type="model"
)

model = joblib.load(model_path)

st.set_page_config(page_title="Wellness Tourism Package Prediction", layout="centered")
st.title("Wellness Tourism Package Purchase Prediction")

age = st.number_input("Customer Age", min_value=18, max_value=80, value=30)
monthly_income = st.number_input("Monthly Income", min_value=1000, max_value=200000, value=50000)
number_of_trips = st.number_input("Number of Trips per Year", min_value=0, max_value=50, value=2)
pitch_score = st.slider("Pitch Satisfaction Score", min_value=1, max_value=5, value=3)

input_df = pd.DataFrame([{
    "Age": age,
    "MonthlyIncome": monthly_income,
    "NumberOfTrips": number_of_trips,
    "PitchSatisfactionScore": pitch_score
}])

if st.button("Predict Purchase Probability"):
    probability = model.predict_proba(input_df)[0][1]
    st.success(f"Predicted Probability of Purchase: {probability:.2f}")
